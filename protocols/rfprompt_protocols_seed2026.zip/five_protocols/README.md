# Five protocols from one locked sample pool

Only task assignment changes. Train/dev/eval membership, audio paths, labels, and
speaker split membership are preserved. No audio is added, removed, or reused.
Protocols 4 and 5 preserve the mixed-real source assignments.

## Definitions

- Protocol 1: dataset-wise real / dataset-wise fake.
- Protocol 2: dataset-wise real / mechanism-wise fake.
- Protocol 3: source-support-matched real / mechanism-wise fake.
- Protocol 4: four-domain mixed real / dataset-wise fake.
- Protocol 5 (RAMI): four-domain mixed real / mechanism-wise fake.

Protocol 3 allocates each domain's fixed real budget across tasks proportionally to that
domain's Fake counts, independently within each split. Largest-remainder rounding
with ascending-task tie breaks preserves integer totals. Utterance assignment uses
SHA256(seed, split, domain, utt_id), not model results. Zero Fake support receives
zero Real from that domain. This matches dataset-source support, not exact per-task
domain proportions, utterance pairs, language, speaker, or acoustic provenance.

Protocol 3 formula: R[t,d] = apportion(R[d] * F[t,d] / sum_t F[t,d]).
Active assignment is task_id and directory. Other inherited task/taxonomy fields
remain source provenance and must not be used to infer reassigned real membership.
Changing eval grouping changes macro EER; compare final Pool EER on the shared pool.
Identical pools alone do not ensure identical optimization budgets or update counts.

## Counts

| Protocol | Split | Task | Real | Fake | Total |
|---|---|---|---:|---:|---:|
| protocol | train | A0 | 2400 | 2500 | 4900 |
| protocol | train | A1 | 2400 | 800 | 3200 |
| protocol | train | A2 | 2400 | 2400 | 4800 |
| protocol | train | A3 | 2400 | 3900 | 6300 |
| protocol | train | B0 | 2400 | 2400 | 4800 |
| protocol | train | B1 | 2400 | 2400 | 4800 |
| protocol | train | B2 | 2400 | 2400 | 4800 |
| protocol | train | B3 | 2400 | 2400 | 4800 |
| protocol | train | B0 | 2304 | 2400 | 4704 |
| protocol | train | B1 | 3419 | 2400 | 5819 |
| protocol | train | B2 | 2400 | 2400 | 4800 |
| protocol | train | B3 | 1477 | 2400 | 3877 |
| protocol | train | A0 | 2400 | 2500 | 4900 |
| protocol | train | A1 | 2400 | 800 | 3200 |
| protocol | train | A2 | 2400 | 2400 | 4800 |
| protocol | train | A3 | 2400 | 3900 | 6300 |
| protocol | train | B0 | 2400 | 2400 | 4800 |
| protocol | train | B1 | 2400 | 2400 | 4800 |
| protocol | train | B2 | 2400 | 2400 | 4800 |
| protocol | train | B3 | 2400 | 2400 | 4800 |
| protocol | dev | A0 | 2400 | 2105 | 4505 |
| protocol | dev | A1 | 2400 | 1135 | 3535 |
| protocol | dev | A2 | 2400 | 2400 | 4800 |
| protocol | dev | A3 | 2400 | 3960 | 6360 |
| protocol | dev | B0 | 2400 | 2400 | 4800 |
| protocol | dev | B1 | 2400 | 2400 | 4800 |
| protocol | dev | B2 | 2400 | 2400 | 4800 |
| protocol | dev | B3 | 2400 | 2400 | 4800 |
| protocol | dev | B0 | 3126 | 2400 | 5526 |
| protocol | dev | B1 | 2619 | 2400 | 5019 |
| protocol | dev | B2 | 2400 | 2400 | 4800 |
| protocol | dev | B3 | 1455 | 2400 | 3855 |
| protocol | dev | A0 | 2400 | 2105 | 4505 |
| protocol | dev | A1 | 2400 | 1135 | 3535 |
| protocol | dev | A2 | 2400 | 2400 | 4800 |
| protocol | dev | A3 | 2400 | 3960 | 6360 |
| protocol | dev | B0 | 2400 | 2400 | 4800 |
| protocol | dev | B1 | 2400 | 2400 | 4800 |
| protocol | dev | B2 | 2400 | 2400 | 4800 |
| protocol | dev | B3 | 2400 | 2400 | 4800 |
| protocol | eval | A0 | 5000 | 4832 | 9832 |
| protocol | eval | A1 | 5000 | 3525 | 8525 |
| protocol | eval | A2 | 5000 | 5000 | 10000 |
| protocol | eval | A3 | 5000 | 6643 | 11643 |
| protocol | eval | B0 | 5000 | 5000 | 10000 |
| protocol | eval | B1 | 5000 | 5000 | 10000 |
| protocol | eval | B2 | 5000 | 5000 | 10000 |
| protocol | eval | B3 | 5000 | 5000 | 10000 |
| protocol | eval | B0 | 5600 | 5000 | 10600 |
| protocol | eval | B1 | 5380 | 5000 | 10380 |
| protocol | eval | B2 | 5000 | 5000 | 10000 |
| protocol | eval | B3 | 4020 | 5000 | 9020 |
| protocol | eval | A0 | 5000 | 4832 | 9832 |
| protocol | eval | A1 | 5000 | 3525 | 8525 |
| protocol | eval | A2 | 5000 | 5000 | 10000 |
| protocol | eval | A3 | 5000 | 6643 | 11643 |
| protocol | eval | B0 | 5000 | 5000 | 10000 |
| protocol | eval | B1 | 5000 | 5000 | 10000 |
| protocol | eval | B2 | 5000 | 5000 | 10000 |
| protocol | eval | B3 | 5000 | 5000 | 10000 |
